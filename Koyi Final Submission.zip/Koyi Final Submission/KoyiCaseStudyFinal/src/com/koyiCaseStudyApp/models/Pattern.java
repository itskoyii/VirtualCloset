package com.koyiCaseStudyApp.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Pattern {

	@Id
	@Column
	private String id;		//PK
	
	@Column
	private String pattern;

	public Pattern() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Pattern(String id, String pattern) {
		super();
		this.id = id;
		this.pattern = pattern;
	}

	public String getId() {
		return id;
	}

	public String getPattern() {
		return pattern;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pattern other = (Pattern) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (pattern == null) {
			if (other.pattern != null)
				return false;
		} else if (!pattern.equals(other.pattern))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Pattern [id=" + id + ", pattern=" + pattern + "]";
	}

	
}
