package com.koyiCaseStudyApp.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Occasion {

	@Id
	@Column
	private String id;		//PK- name
	
	@Column
	private String occasion;	

	public Occasion() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Occasion(String id, String occasion) {
		super();
		this.id = id;
		this.occasion = occasion;
	}

	public String getId() {
		return id;
	}

	public String getOccasion() {
		return occasion;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setOccasion(String occasion) {
		this.occasion = occasion;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Occasion other = (Occasion) obj;
		if (id != other.id)
			return false;
		if (occasion == null) {
			if (other.occasion != null)
				return false;
		} else if (!occasion.equals(other.occasion))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Occasion [id=" + id + ", occasion=" + occasion + "]";
	}
	
	
}
