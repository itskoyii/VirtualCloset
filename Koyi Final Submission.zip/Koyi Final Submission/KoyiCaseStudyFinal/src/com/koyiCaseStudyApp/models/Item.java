package com.koyiCaseStudyApp.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Item {

	@Id
	@Column
	int id;		//PK
	
	@Column
	int userId;	//FK

	@Column
	String description;
	
	@Column
	String colorId;	//FK
	
	@Column
	String patternId;	//FK
	
	@Column
	String occasionId;	//FK
	
	@Column
	String categoryId;		//FK
	
	@Column
	String subCategoryId;	//FK
	
	@Column
	String imageFront;
	
	@Column
	String imageBack;
	
	@Column
	String brandId;	//FK

	public Item() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Item(int userId, int id, String description, String colorId, String patternId, String occasionId,
			String categoryId, String subCategoryId, String imageFront, String imageBack, String brandId) {
		super();
		this.userId = userId;
		this.id = id;
		this.description = description;
		this.colorId = colorId;
		this.patternId = patternId;
		this.occasionId = occasionId;
		this.categoryId = categoryId;
		this.subCategoryId = subCategoryId;
		this.imageFront = imageFront;
		this.imageBack = imageBack;
		this.brandId = brandId;
	}

	public int getUserId() {
		return userId;
	}

	public int getId() {
		return id;
	}

	public String getDescription() {
		return description;
	}

	public String getColorId() {
		return colorId;
	}

	public String getPatternId() {
		return patternId;
	}

	public String getOccasionId() {
		return occasionId;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public String getSubCategoryId() {
		return subCategoryId;
	}

	public String getImageFront() {
		return imageFront;
	}

	public String getImageBack() {
		return imageBack;
	}

	public String getBrandId() {
		return brandId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setColorId(String colorId) {
		this.colorId = colorId;
	}

	public void setPatternId(String patternId) {
		this.patternId = patternId;
	}

	public void setOccasionId(String occasionId) {
		this.occasionId = occasionId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public void setSubCategoryId(String subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public void setImageFront(String imageFront) {
		this.imageFront = imageFront;
	}

	public void setImageBack(String imageBack) {
		this.imageBack = imageBack;
	}

	public void setBrandId(String brandId) {
		this.brandId = brandId;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (brandId == null) {
			if (other.brandId != null)
				return false;
		} else if (!brandId.equals(other.brandId))
			return false;
		if (categoryId == null) {
			if (other.categoryId != null)
				return false;
		} else if (!categoryId.equals(other.categoryId))
			return false;
		if (colorId == null) {
			if (other.colorId != null)
				return false;
		} else if (!colorId.equals(other.colorId))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (id != other.id)
			return false;
		if (imageBack == null) {
			if (other.imageBack != null)
				return false;
		} else if (!imageBack.equals(other.imageBack))
			return false;
		if (imageFront == null) {
			if (other.imageFront != null)
				return false;
		} else if (!imageFront.equals(other.imageFront))
			return false;
		if (occasionId == null) {
			if (other.occasionId != null)
				return false;
		} else if (!occasionId.equals(other.occasionId))
			return false;
		if (patternId == null) {
			if (other.patternId != null)
				return false;
		} else if (!patternId.equals(other.patternId))
			return false;
		if (subCategoryId == null) {
			if (other.subCategoryId != null)
				return false;
		} else if (!subCategoryId.equals(other.subCategoryId))
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Item [userId=" + userId + ", id=" + id + ", description=" + description + ", colorId=" + colorId
				+ ", patternId=" + patternId + ", occasionId=" + occasionId + ", categoryId=" + categoryId
				+ ", subCategoryId=" + subCategoryId + ", imageFront=" + imageFront + ", imageBack=" + imageBack
				+ ", brandId=" + brandId + "]";
	}

}