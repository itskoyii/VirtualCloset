package com.koyiCaseStudyApp.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Brand {

	@Id
	@Column
	private String id;
	
	@Column
	private String brand;

	public Brand() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Brand(String id, String brand) {
		super();
		this.id = id;
		this.brand = brand;
	}

	public String getId() {
		return id;
	}

	public String getBrand() {
		return brand;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Brand other = (Brand) obj;
		if (brand == null) {
			if (other.brand != null)
				return false;
		} else if (!brand.equals(other.brand))
			return false;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Brand [id=" + id + ", brand=" + brand + "]";
	}

	
}
