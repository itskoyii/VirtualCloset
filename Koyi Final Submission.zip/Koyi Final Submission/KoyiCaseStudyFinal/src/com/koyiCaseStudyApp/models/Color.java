package com.koyiCaseStudyApp.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Color {

	@Id
	@Column
	private String id;	
	
	@Column
	private String color;

	public Color() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Color(String id, String color) {
		super();
		this.id = id;
		this.color = color;
	}

	public String getId() {
		return id;
	}

	public String getColor() {
		return color;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setColor(String color) {
		this.color = color;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Color other = (Color) obj;
		if (color == null) {
			if (other.color != null)
				return false;
		} else if (!color.equals(other.color))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Color [id=" + id + ", color=" + color + "]";
	}

	
	
}
