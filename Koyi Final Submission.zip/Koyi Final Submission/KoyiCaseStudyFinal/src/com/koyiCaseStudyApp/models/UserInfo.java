package com.koyiCaseStudyApp.models;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import com.koyiCaseStudyApp.models.UserInfo;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

//Class level annotations
@Entity
@Table

public class UserInfo {

	@Id 	//primary keys
//	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@GeneratedValue(generator="Sequence")
	@SequenceGenerator(name="Sequence", sequenceName = "seq", allocationSize = 1)
//	@OneToOne
	private int id;
	
	@Basic
	@Column
	@NotNull
	@Size(min=5, max=15, message = "User name must be between {2} and {1}")
	private String username;
	
	@Basic
	@Column
	@Size(min=5, max=15, message = "Password must be between {2} and {1}")
	private String firstName;

	@Basic
	@Column
	private String lastName;
	
	@Basic
	@Column
	private String email;
	
	@Basic
	@Column
	private String password;
	
	@Basic
	@Column
	private String confirmPassword;
	
	@Basic
	@Column
	private boolean remember;
	
	@Basic
	@Column
	private boolean gender; 	// true- female, false- male
	
	private String profilePic;
	
	//constructor
	public UserInfo() {
		super();
	}


	public UserInfo(String username, String firstName, String lastName, String email, String password,
			String confirmPassword, boolean remember, boolean gender, String profilePic) {
		super();
		this.username = username;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.remember = remember;
		this.gender = gender;
		this.profilePic = profilePic;
	}

	public UserInfo(String firstName) {
		super();
		this.firstName = firstName;

	}
	
	public int getId() {
		return id;
	}


	public String getUsername() {
		return username;
	}


	public String getFirstName() {
		return firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public String getEmail() {
		return email;
	}


	public String getPassword() {
		return password;
	}


	public String getConfirmPassword() {
		return confirmPassword;
	}


	public boolean isRemember() {
		return remember;
	}


	public boolean isGender() {
		return gender;
	}

	
	public String getProfilePic() {
		return profilePic;
	}
	
	public void setId(int id) {
		this.id = id;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}


	public void setRemember(boolean remember) {
		this.remember = remember;
	}


	public void setGender(boolean gender) {
		this.gender = gender;
	}

	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}
	
	
	// generate toString using fields
	@Override
	public String toString() {
		return "UserInfo [id=" + id + ", username=" + username + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", email=" + email + ", password=" + password + ", confirmPassword=" + confirmPassword + ", remember="
				+ remember + ", gender=" + gender + ", profilePic=" + profilePic + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserInfo other = (UserInfo) obj;
		if (confirmPassword == null) {
			if (other.confirmPassword != null)
				return false;
		} else if (!confirmPassword.equals(other.confirmPassword))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (gender != other.gender)
			return false;
		if (id != other.id)
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (profilePic == null) {
			if (other.profilePic != null)
				return false;
		} else if (!profilePic.equals(other.profilePic))
			return false;
		if (remember != other.remember)
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}
	
}
