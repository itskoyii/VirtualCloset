package com.koyiCaseStudyApp.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table
public class SubCategory {

	@Id
	@Column
	private String id;				//PK
	
	@Column
	private String categoryId;		//FK
	
	@Column
	private String subCategory;		//subCategory name

	public SubCategory() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SubCategory(String id, String categoryId, String subCategory) {
		super();
		this.id = id;
		this.categoryId = categoryId;
		this.subCategory = subCategory;
	}

	public String getId() {
		return id;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public String getSubCategory() {
		return subCategory;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SubCategory other = (SubCategory) obj;
		if (categoryId == null) {
			if (other.categoryId != null)
				return false;
		} else if (!categoryId.equals(other.categoryId))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (subCategory == null) {
			if (other.subCategory != null)
				return false;
		} else if (!subCategory.equals(other.subCategory))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SubCategory [id=" + id + ", categoryId=" + categoryId + ", subCategory=" + subCategory + "]";
	}

	
	
}
