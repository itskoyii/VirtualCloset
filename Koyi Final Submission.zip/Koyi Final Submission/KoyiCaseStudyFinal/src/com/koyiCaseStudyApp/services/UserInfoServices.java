package com.koyiCaseStudyApp.services;

import com.koyiCaseStudyApp.dao.UserInfoDao;
import com.koyiCaseStudyApp.models.UserInfo;

//3.
// Layer of abstraction
// used for business logic of the application's business requirements
// Connecting to the DAO operations- focused on interacting with the database
public class UserInfoServices {

	public int loginService(UserInfo userInfo) {
		int result = new UserInfoDao().getUserByUsernameAndPassword(userInfo);
		return result;
	}

	public int signUpService(UserInfo newUser) {
		int result = new UserInfoDao().addUser(newUser);
		return result;
	}

	public UserInfo getUserByUsernameService(UserInfo userInfo) {
		UserInfo result = new UserInfoDao().getUserByUsername(userInfo);
		return result;
	}
	
	
	
}
