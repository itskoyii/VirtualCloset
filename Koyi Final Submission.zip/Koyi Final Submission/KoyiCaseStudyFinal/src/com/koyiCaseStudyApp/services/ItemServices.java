package com.koyiCaseStudyApp.services;

import java.util.List;

import com.koyiCaseStudyApp.dao.ItemDao;
import com.koyiCaseStudyApp.models.Item;

//3.
//Layer of abstraction
//used for business logic of the application's business requirements
//Connecting to the DAO operations- focused on interacting with the database
// From Dao to Services
public class ItemServices {

	public int addItemService(Item newItem) {		//same parameter as addItem in Dao class
		int result = new ItemDao().addItem(newItem);
		return result;
	}
	
	public int editItemService(int id, Item newItem) {
		int result = new ItemDao().editItem(id, newItem);
		return result;
	}
	
	public int deleteItemService(int id) {
		int result = new ItemDao().deleteItem(id);
		return result;
	}
	
	public List<Item> getItemServiceByDescription(String description) {
		List<Item> result = new ItemDao().getItemsByDescription(description);
		return result;
	}
	
	public List<Item> getItemServiceBySubCategory(String subCategory) {
		List<Item> result = new ItemDao().getItemsBySubCategory(subCategory);
		return result;
	}
	
	public List<Item> getItemServiceByColorId(String colorId) {
		List<Item> result = new ItemDao().getItemsByColor(colorId);
		return result;
	}
	
	public List<Item> getItemServiceByPatternId(String patternId) {
		List<Item> result = new ItemDao().getItemsByPattern(patternId);
		return result;
	}
	
	public List<Item> getItemServiceByBrandId(String brandId) {
		List<Item> result = new ItemDao().getItemsByBrand(brandId);
		return result;
	}
	
	public List<Item> getItemServiceByOccasionId(String occasionId) {
		List<Item> result = new ItemDao().getItemsByOccasion(occasionId);
		return result;
	}
}
