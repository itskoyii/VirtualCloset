package com.koyiCaseStudyApp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import com.koyiCaseStudyApp.models.Item;

// 2.
// fetch or store data to or from the database
// Execute SQL statements
// Contains CRUD operations
public class ItemDao implements ItemDaoI {

	private static final String persistenceUnitName = "KoyiCaseStudyFinal";

	@Override
	public int addItem(Item newItem) {
		System.out.println("***************************************" + newItem.toString());
		EntityManagerFactory emf = null;
		EntityManager em = null;
		int result = 0;

		try {
			// 1. Connect
			emf = Persistence.createEntityManagerFactory(persistenceUnitName);
			em = emf.createEntityManager();

			// 2. Execute- transaction needed
			em.getTransaction().begin();
			em.persist(newItem);
			em.getTransaction().commit();
			System.out.println("---------------------ADD--------------------");
			result = 1; // added successfully

		} catch (Exception e) {
			System.out.println("--------------------CATCH-------------------");
			e.printStackTrace();
			result = 0; // error

		} finally {
			// 3. Disconnect
			em.close();
			emf.close();
		}
		return result;
	}

	@Override
	public int editItem(int id, Item newItem) {
		int result = 0;		
		// 1. Connect
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		EntityManager em = emf.createEntityManager();
		
		// 2. Execute - need transaction
		Item foundItem = em.find(Item.class, id);
		//update properties of the found item
		if (foundItem != null) {
			em.getTransaction().begin();
				foundItem.setId(newItem.getId());
				foundItem.setCategoryId(newItem.getCategoryId());
				foundItem.setSubCategoryId(newItem.getSubCategoryId());
				foundItem.setColorId(newItem.getColorId());
				foundItem.setPatternId(newItem.getPatternId());
				foundItem.setDescription(newItem.getDescription());
				foundItem.setBrandId(newItem.getBrandId());
				foundItem.setOccasionId(newItem.getOccasionId());
				foundItem.setImageFront(newItem.getImageFront());
				foundItem.setImageBack(newItem.getImageBack());
			em.getTransaction().commit();
			result = 1;
		}
		// 3. Disconnect
		em.close();
		emf.close();
		return result;
	}

	@Override
	public int deleteItem(int id) {
		int result = 0;		
		
		// 1. Connect
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		EntityManager em = emf.createEntityManager();
		
		// 2. Execute - need transaction
		Item foundItem = em.find(Item.class, id);	//finding the existing item by primary key
		if (foundItem != null) {			
			em.getTransaction().begin();
			em.remove(foundItem);
			em.getTransaction().commit();
			result = 1;		//removed successfully
		}
		// 3. Disconnect
		em.close();
		emf.close();
		return result;
	}


	@Override
	public List<Item> getItemsByDescription(String description) {
		// 1. Connect
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		EntityManager em = emf.createEntityManager();
		// 2. Execute- no need transaction for this operation
		Query query = em.createQuery("SELECT i FROM Item i WHERE i.description LIKE :givenDescription");	//JPQL

		query.setParameter("givenDescription", "%" + description + "%");	 
		List<Item> descriptionList = query.getResultList();
				
		// 3. Disconnect
		em.close();
		emf.close();
		return descriptionList;
	}

	@Override
	public List<Item> getItemsBySubCategory(String subCategoryId) {
		// 1. Connect
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		EntityManager em = emf.createEntityManager();
		// 2. Execute- no need transaction for this operation
		Query query = em.createQuery("SELECT i FROM Item i WHERE i.subCategoryId = :givenSubCategoryId");

		query.setParameter("givenSubCategoryId", subCategoryId);
		 
		List<Item> subCategoryList = query.getResultList();
		
		// 3. Disconnect
		em.close();
		emf.close();
		
		return subCategoryList;
	}

	public List<Item> getItemsByColor(String colorId) {
		// 1. Connect
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		EntityManager em = emf.createEntityManager();
		// 2. Execute- no need transaction for this operation
		Query query = em.createQuery("SELECT i FROM Item i WHERE i.colorId = :givenColorId");

		query.setParameter("givenColorId", colorId);
		 
		List<Item> colorList = query.getResultList();
		
		// 3. Disconnect
		em.close();
		emf.close();
		
		return colorList;
	}

	public List<Item> getItemsByPattern(String patternId) {
		// 1. Connect
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		EntityManager em = emf.createEntityManager();
		// 2. Execute- no need transaction for this operation
		Query query = em.createQuery("SELECT i FROM Item i WHERE i.patternId = :givenPatternId");
		query.setParameter("givenPatternId", patternId);
		 
		List<Item> patternList = query.getResultList();
		// 3. Disconnect
		em.close();
		emf.close();
		
		return patternList;
	}

	@Override
	public List<Item> getItemsByBrand(String brandId) {
		// 1. Connect
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		EntityManager em = emf.createEntityManager();
		// 2. Execute- no need transaction for this operation
		Query query = em.createQuery("SELECT i FROM Item i WHERE i.brandId = :givenBrandId");
		query.setParameter("givenBrandId", brandId);
		 
		List<Item> brandList = query.getResultList();
		
		// 3. Disconnect
		em.close();
		emf.close();
		
		return brandList;
	}
	
	@Override
	public List<Item> getItemsByOccasion(String occasionId) {
		// 1. Connect
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		EntityManager em = emf.createEntityManager();
		// 2. Execute- no need transaction for this operation
		Query query = em.createQuery("SELECT i FROM Item i WHERE i.occasionId = :givenOccasionId");
		query.setParameter("givenOccasionId", occasionId);
	
		List<Item> occasionList = query.getResultList();
		
		// 3. Disconnect
		em.close();
		emf.close();
		
		return occasionList;
	}
	
}
