package com.koyiCaseStudyApp.dao;

import com.koyiCaseStudyApp.models.UserInfo;

// 1.
// Interface- contains only the name and functionality (name and parameters). All members of an interface are implicitly public
// An interface cannot be instantiated, so it does not define a constructor. 
// Interface may contain static methods

public interface UserInfoDaoI {

	public int addUser(UserInfo newUser); 							//create new user in sign up page
	
	public int getUserByUsernameAndPassword(UserInfo userInfo);		//for login page
	
	public int getUserById(UserInfo userInfo);
	
	public int updateUser (String username, UserInfo newUser); 
	
	public int deleteUser (String username);

	UserInfo getUserByUsername(UserInfo userInfo);
	


	
	
}
