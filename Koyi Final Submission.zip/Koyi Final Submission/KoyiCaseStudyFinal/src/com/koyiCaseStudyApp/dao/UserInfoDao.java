package com.koyiCaseStudyApp.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.koyiCaseStudyApp.models.UserInfo;

//2. 
// fetch or store data to or from the database
// Execute SQL statements
// Contains CRUD operations
public class UserInfoDao implements UserInfoDaoI {

	private static final String persistenceUnitName = "KoyiCaseStudyFinal";

	@Override
	public int getUserById(UserInfo userInfo) {
		int result = 0;
		
		EntityManagerFactory emf = null;
		EntityManager em = null;
		
		try {
		// 1. Connect
		emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		em = emf.createEntityManager();
		// 2. Execute- no need transaction
		
		UserInfo ul = em.find(UserInfo.class, userInfo.getId());
		
		if (ul != null && ul.getPassword().equals(userInfo.getPassword())) {
			result = 1;
		} else if (ul != null && !ul.getPassword().equals(userInfo.getPassword())) {
			result = 2;
		} else 
			result = 0;
		
		} catch(Exception e) {
			result = 3;
			
		} finally {
		// 3. Disconnect
		em.close();
		emf.close();
		}
		return result;
	} //getUserById

	@Override
	public UserInfo getUserByUsername(UserInfo userInfo) {
		UserInfo result = null;		//null by default
		
		EntityManagerFactory emf = null;
		EntityManager em = null;
		
		try {
		// 1. Connect
		emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		em = emf.createEntityManager();
		// 2. Execute- no need transaction
		Query query = em.createQuery("SELECT ul FROM UserInfo ul WHERE ul.username = :givenUsername");
		query.setParameter("givenUsername", userInfo.getUsername());
		UserInfo ul = (UserInfo) query.getSingleResult();
		System.out.println("****************" + ul.toString());
		
		if (ul != null) {
			result = ul;		//correct
		}
			
		} catch(Exception e) {
			e.printStackTrace();
			result = null;
			
		} finally {
		// 3. Disconnect
		em.close();
		emf.close();
		}
		return result;
	} //getUserByUsername
	
	@Override
	public int getUserByUsernameAndPassword(UserInfo userInfo) {
		int result = 0;		//incorrect by default
		
		EntityManagerFactory emf = null;
		EntityManager em = null;
		
		try {
		// 1. Connect
		emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		em = emf.createEntityManager();
		// 2. Execute- no need transaction
		Query query = em.createQuery("SELECT ul FROM UserInfo ul WHERE ul.username = :givenUsername");
		query.setParameter("givenUsername", userInfo.getUsername());
		UserInfo ul = (UserInfo) query.getSingleResult();
		System.out.println("****************" + ul.toString());
		
		if (ul != null && ul.getPassword().equals(userInfo.getPassword())) {
			result = 1;		//correct
		} else if (ul != null && !ul.getPassword().equals(userInfo.getPassword())) {
			result = 2;		//incorrect pw
		} else 
			result = 0;		//incorrect
			
		} catch(Exception e) {
			e.printStackTrace();
			result = 3;
			
		} finally {
		// 3. Disconnect
		em.close();
		emf.close();
		}
		return result;
	} //getUserByUsernameAndPassword
	
	
	@Override
	public int addUser(UserInfo newUser) {
		System.out.println("***************************************" + newUser.toString());
		EntityManagerFactory emf = null;
		EntityManager em = null;
		int result = 0;

		try {
			// 1. Connect
			emf = Persistence.createEntityManagerFactory(persistenceUnitName);
			em = emf.createEntityManager();

			// 2. Execute- transaction needed
			em.getTransaction().begin();
			em.persist(newUser);
			em.getTransaction().commit();
			System.out.println("---------------------ADD--------------------");
			result = 1; // added successfully

		} catch (Exception e) {
			System.out.println("--------------------CATCH-------------------");
			e.printStackTrace();
			result = 0; // error

		} finally {
			// 3. Disconnect
			em.close();
			emf.close();
		}
		return result;
	}


	// This method update the user by username, the user can update their email, pw, profile pic, first and last name.
	@Override
	public int updateUser(String username, UserInfo newUser) {
		int result = 0;		
		
		// 1. Connect
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		EntityManager em = emf.createEntityManager();
		
		// 2. Execute - need transaction
		UserInfo foundUser = em.find(UserInfo.class, username);	//finding the existing user by username
		if (foundUser != null) {			
			em.getTransaction().begin();
			foundUser.setEmail(newUser.getEmail());				// get the user's new email and set that as the email
			foundUser.setFirstName(newUser.getFirstName());
			foundUser.setLastName(newUser.getLastName());
			foundUser.setPassword(newUser.getPassword());
			foundUser.setConfirmPassword(newUser.getConfirmPassword());
			em.getTransaction().commit();
			result = 1;		// if found
		}
		// 3. Disconnect
		em.close();
		emf.close();
		return result;
	}

	@Override
	public int deleteUser(String username) {
		int result = 0;		
		
		// 1. Connect
		EntityManagerFactory emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		EntityManager em = emf.createEntityManager();
		
		// 2. Execute - need transaction
		UserInfo foundUser = em.find(UserInfo.class, username);	//finding the existing user by username
		if (foundUser != null) {			
			em.getTransaction().begin();
			em.remove(foundUser);
			em.getTransaction().commit();
			result = 1;
		}
		// 3. Disconnect
		em.close();
		emf.close();
		return result;
	}
}
