package com.koyiCaseStudyApp.dao;

import java.util.List;

import com.koyiCaseStudyApp.models.Item;

// 1.
// Interface- contains only the name and functionality (name and parameters). All members of an interface are implicitly public
// An interface cannot be instantiated, so it does not define a constructor. 
// Interface may contain static methods

public interface ItemDaoI {

	public int addItem(Item newItem);								//add new item
	
	public int editItem(int id, Item newItem);						//edit item by id with new item 
	
	public int deleteItem(int id);									//deletes item by item id
	
	public List<Item> getItemsByDescription(String description);	//get list of items in the search bar by description
	
	public List<Item> getItemsBySubCategory(String subCategory);	//get list of items in the search bar by sub category
	
	public List<Item> getItemsByColor(String colorId);
	
	public List<Item> getItemsByPattern(String patternId);
	
	public List<Item> getItemsByBrand(String brandId);				//get list of items in the search bar by brand

	public List<Item> getItemsByOccasion(String occasionId);
	
}
