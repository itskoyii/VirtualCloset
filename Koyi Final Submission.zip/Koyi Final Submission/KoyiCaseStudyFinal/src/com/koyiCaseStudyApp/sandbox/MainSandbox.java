package com.koyiCaseStudyApp.sandbox;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.koyiCaseStudyApp.models.Item;
import com.koyiCaseStudyApp.models.UserInfo;
import com.koyiCaseStudyApp.services.ItemServices;
import com.koyiCaseStudyApp.services.UserInfoServices;

//4. 
public class MainSandbox {

	private static ItemServices is = new ItemServices();
	private static String persistenceUnitName = "KoyiCaseStudyFinal";

	public static void main(String[] args) {
		// testDBConnection();
		// testLogin();
		// testSignUp();

		// testAddItem();
		// testDeleteItemById(100);
		// testgetItemServiceByDescription();
		// testgetItemServiceByColor();
		// testgetItemServiceByPattern();
		// testGetItemsByBrand();
			testGetItemsByOccasion();
	}

	private static void testLogin() {
		UserInfo userInfo = new UserInfo();
		userInfo.setUsername("koyit");
		userInfo.setPassword("12345678");
		int result = new UserInfoServices().loginService(userInfo);
		System.out.println("-------------------------" + result);

		if (result == 1) {
			System.out.println("home");
		} else
			System.out.println("error");
	}

	private static void testSignUp() {
		UserInfo newUser = new UserInfo();
		newUser.setUsername("lily123");
		newUser.setEmail("lily@g.com");
		newUser.setPassword("1234567890");
		newUser.setConfirmPassword("1234567890");
		newUser.setFirstName("Lily");
		newUser.setLastName("Chen");
		newUser.setGender(true);

		int result = new UserInfoServices().signUpService(newUser);
		System.out.println("-------------------------" + result);

		if (result == 1) {
			System.out.println("home");
		} else
			System.out.println("login");
	}

	private static void testDBConnection() {
		EntityManagerFactory emf = null;
		EntityManager em = null;

		// 1. Connect
		emf = Persistence.createEntityManagerFactory(persistenceUnitName);
		em = emf.createEntityManager();
		// 2. Execute- no need transaction

		// 3. Disconnect
		em.close();
		emf.close();
	}

	// ************************ Testing for Item Services *****************************

	private static void testAddItem() {
		Item item = new Item();
		item.setId(100);
		item.setUserId(1001);
		item.setDescription("Mock Neck Sweater");
		item.setCategoryId("Tops");
		item.setSubCategoryId("Sweater");
		item.setColorId("Black");
		item.setPatternId("None");
		item.setOccasionId("Casual");
		item.setBrandId("J.Crew");
		item.setImageFront("f100.jpg");
		item.setImageBack("b100.jpg");

		int result = new ItemServices().addItemService(item);
		System.out.println("-------------------------" + result);
		if (result == 1) { // success
			System.out.println("Added");
		} else
			System.out.println("Failed");
	}

	private static void testDeleteItemById(int id) {
		// int itemId = 100;
		int result = is.deleteItemService(id);
		System.out.println("------------------" + result);

		if (result == 1) { // success
			System.out.println("Deleted successfully");
		} else
			System.out.println("Delete Failed");
	}


	private static void testgetItemServiceByDescription() {
		String description = "neck";
		List<Item> result = new ItemServices().getItemServiceByDescription(description);
		System.out.println("----------------------" + result);
		if (result != null) {
			System.out.println("Result found.");
			System.out.println(result.toString());
		} else
			System.out.println("Result not found");
	}

	private static void testgetItemServiceByColor() {
		String color = "white";
		List<Item> result = new ItemServices().getItemServiceByColorId(color);
		System.out.println("----------------------" + result);
		if (result != null) {
			System.out.println("Result found.");
			System.out.println(result.toString());
		} else
			System.out.println("Result not found");
	}

	private static void testgetItemServiceByPattern() {
		String pattern = "Floral";
		List<Item> result = new ItemServices().getItemServiceByPatternId(pattern);
		System.out.println("----------------------" + result);
		if (result != null) {
			System.out.println("Result found.");
			System.out.println(result.toString());
		} else
			System.out.println("Result not found");
	}
	
	private static void testGetItemsByBrand() {
		String brand = "H&M";
		List<Item> result = new ItemServices().getItemServiceByBrandId(brand);
		System.out.println("----------------------" + result);
		if (result != null) {
			System.out.println("Result found.");
			System.out.println(result.toString());
		} else
			System.out.println("Result not found");
	}

	private static void testGetItemsByOccasion() {
		String occasion = "Casual";
		List<Item> result = new ItemServices().getItemServiceByOccasionId(occasion);
		System.out.println("----------------------" + result);
		if (result != null) {
			System.out.println("Result found.");
			System.out.println(result.toString());
		} else
			System.out.println("Result not found");
	}
	
	
}
