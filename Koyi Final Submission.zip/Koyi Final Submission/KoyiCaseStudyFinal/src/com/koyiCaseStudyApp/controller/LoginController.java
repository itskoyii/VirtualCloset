package com.koyiCaseStudyApp.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.koyiCaseStudyApp.models.UserInfo;
import com.koyiCaseStudyApp.services.UserInfoServices;

// First step. Class level annotations
@Controller
@SessionAttributes({"userInfo","userInfoSession"})		//#1
public class LoginController {
	// properties or fields
	// Constructors
	// methods
	UserInfoServices uis = new UserInfoServices();		
	
	@ModelAttribute("userInfo")							//#2. name of the object you are storing in the session in the session object, should match with @@SessionAttributes
	public UserInfo setUpUserInfoSession() {
		return new UserInfo();
	}
	
	
	// method annotations
	//@ -> annotation & RequestMapping is the name of the annotation. How to handler multiple pages 
	@RequestMapping(value = {"/","/login"})		// uri
	public String loginHandler() {		//@SessionAttribute("userInfo") UserInfo userInfoSession
		return "login";	//this is the view, that will be use for the response for the request. This is the name of JSP file.
	} // login
	
//	@ModelAttribute("userInfoSession")
//	public UserInfo setUpUserLoginSession() {
//		return new UserInfo("Username", "Password", false);
//	}
//	

	@RequestMapping("/signIn")	//uri
	public ModelAndView signInHandler(
			@ModelAttribute UserInfo userInfo						//reading from http request (request object)
	//		@SessionAttribute("userInfo") UserInfo userInfoSession		//#4.1. reading from session object
		) {	
			
		System.out.println(userInfo.toString());
	
		ModelAndView mav = new ModelAndView();	
		String viewName = "home";
				
	int result = uis.loginService(userInfo);
	if(result == 1) {
		
	UserInfo foundUser = uis.getUserByUsernameService(userInfo);
	
		mav.addObject("userInfo", foundUser);	// will contain userInfo (response object)
		viewName = "home";	
	} else {
		viewName = "loginFail";
	}
	mav.setViewName(viewName);
	return mav;
	}
	
	@RequestMapping("/forgotPassword")
	public String forgotHandler() {
		return "forgotPassword";
	} //forgot
	
	@RequestMapping("/signUpRm") //processing the form method (action)
	public String signUpFormHandler(@ModelAttribute UserInfo newUser) {
		
		int result = new UserInfoServices().signUpService(newUser);
		if(result == 1) {
			return "home";
		} else
			return "login";
		}
	
	@RequestMapping("/signOut")
	public String signOutHandler() {
		return "signOut";
	} //signOut
	
	@RequestMapping("/signOutRm")
	public ModelAndView signOutRmHandler(HttpSession session) {		//invalidate the session in the handler
		System.out.println("***************************"+session.getId());
		ModelAndView mav = new ModelAndView();
		mav.setViewName("login");
		mav.addObject("userInfo",new UserInfo());		// #3.1
		session.invalidate();
		return mav;
	} //signOutRm
	
}
