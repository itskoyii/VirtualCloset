package com.koyiCaseStudyApp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.koyiCaseStudyApp.models.UserInfo;

// First step. Class level annotations
@Controller
@SessionAttributes({"userInfo"})	//",cartSession"	

public class MainController {
	// properties or fields
	// Constructors
	// methods
	
	@ModelAttribute("userInfo")		//name of the object you are storing in the session in the session object, should match with @@SessionAttributes
	public UserInfo setUpUserInfoSession() {
		return new UserInfo();
	}
	
//	sample:	
//	@ModelAttribute("cartSession")		
//	public String setUpCartSession() {
//		return "My Shopping Cart";
//	}
	
	@RequestMapping("/home")
	public String homeHandler() {	//@SessionAttribute("userInfo") UserInfo userInfo
		return "home";
	}
	
	
	@RequestMapping("/signUpFormRm")		//href from login.jsp to Sign Up page
	public String signUpFormHandler() {
		return "signUpForm";				// jsp
	}

	@RequestMapping("/myCloset")
	public String myClosetHandler() {
		return "myCloset";
	}
	
	@RequestMapping("/aboutUs")
	public String aboutUsHandler() {
		return "aboutUs";
	}
	
	@RequestMapping("/contactUs")
	public String contactUsHandler() {
		return "contactUs";
	}
	
	@RequestMapping("/accountProfile")
	public String profileHandler() {
		return "accountProfile";
	}
	
	@RequestMapping("/addImages")		//href
	public String addImagesHandler() {
		return "addItem";				//jsp
	}
	
	@RequestMapping("/uploadProfilePic")
	public ModelAndView uploadProfilePicHandler(
			@ModelAttribute UserInfo newUser,
			@RequestParam() String username,
			@RequestParam() String profilePic) {
		
		ModelAndView mav = new ModelAndView();	
		String viewName = "home";
		
		System.out.println("*******" + newUser.toString());
		System.out.println("******" + username);
		
		//upload file
		String dbUploadsPath = "resources/dbUploads/";
		
		int result = 1;
		if(result == 1) {
			mav.addObject("profilePic", profilePic);
			mav.addObject("dbUploadsPath",dbUploadsPath);
			viewName = "profile";
		}
 		mav.setViewName(viewName);
		return mav;
	}
	
}
	